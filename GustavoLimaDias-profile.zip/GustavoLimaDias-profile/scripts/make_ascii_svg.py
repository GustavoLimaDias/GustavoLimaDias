"""
make_ascii_svg.py — convert source-prepped.png into a monochrome ASCII
portrait that "prints" itself row by row using SMIL animation.

Usage: python scripts/make_ascii_svg.py
Output: avi-ascii.svg  (kept as avi-ascii.svg to match the article; rename
        freely, the README just needs to reference whatever you pick)
"""
import os
import numpy as np
from PIL import Image

STATIC = os.environ.get("STATIC") == "1"

SRC = "source-prepped.png"
OUT = "gustavo-ascii.svg"

COLS = 72
ROWS = 90
RAMP = " .`:-=+*cs#%@"   # bright (sparse) -> dark (dense); leading space = blank
FONT_SIZE = 8
CHAR_W = FONT_SIZE * 0.6
CHAR_H = FONT_SIZE * 1.0
COLOR = "#9fd3c7"
BG = "transparent"
ROW_STAGGER = 0.05   # seconds between each row starting its wipe
ROW_DURATION = 0.35  # seconds for a single row to wipe in


def image_to_ascii(path, cols, rows):
    im = Image.open(path).convert("L")

    # Downsample FIRST (LANCZOS smooths pixel-level segmentation noise),
    # then stretch tonal range on the small array using only the subject
    # pixels (background was composited to pure white, so it's excluded).
    # Stretching before downsampling amplifies noise into visual speckle.
    small = im.resize((cols, rows), Image.LANCZOS)
    raw = np.array(small).astype(np.float32)

    fg = raw[raw < 248]
    if fg.size:
        lo, hi = np.percentile(fg, [3, 97])
        stretched = np.clip((raw - lo) / max(hi - lo, 1e-3), 0, 1)
        stretched = stretched ** 0.9  # slight gamma lift for midtones
    else:
        stretched = raw / 255.0
    stretched[raw >= 248] = 1.0

    arr = stretched  # 0=black,1=white

    n = len(RAMP) - 1
    lines = []
    for y in range(rows):
        row_chars = []
        for x in range(cols):
            brightness = arr[y, x]
            if brightness > 0.96:
                row_chars.append(RAMP[0])
                continue
            idx = int(round((1.0 - brightness) * n))
            row_chars.append(RAMP[idx])
        lines.append("".join(row_chars))
    return lines


def esc(c):
    return {"&": "&amp;", "<": "&lt;", ">": "&gt;"}.get(c, c)


def build_svg(lines, cols, rows):
    width = cols * CHAR_W
    height = rows * CHAR_H
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:.0f} {height:.0f}" '
        f'width="{width:.0f}" height="{height:.0f}">',
        "<style>",
        f".ascii-row {{ font-family: 'Courier New', ui-monospace, monospace; "
        f"font-size: {FONT_SIZE}px; fill: {COLOR}; white-space: pre; }}",
        "</style>",
    ]
    if BG != "transparent":
        parts.append(f'<rect width="100%" height="100%" fill="{BG}"/>')

    for i, line in enumerate(lines):
        y = (i + 1) * CHAR_H
        start = i * ROW_STAGGER
        row_w = len(line.rstrip()) * CHAR_W
        if row_w <= 0:
            continue
        clip_id = f"clip{i}"
        text = "".join(esc(c) for c in line)
        parts.append(f'<clipPath id="{clip_id}">')
        if STATIC:
            parts.append(
                f'  <rect x="0" y="{y - CHAR_H:.1f}" width="{row_w:.1f}" height="{CHAR_H:.1f}"/>'
            )
        else:
            parts.append(
                f'  <rect x="0" y="{y - CHAR_H:.1f}" width="0" height="{CHAR_H:.1f}">'
            )
            parts.append(
                f'    <animate attributeName="width" from="0" to="{row_w:.1f}" '
                f'begin="{start:.2f}s" dur="{ROW_DURATION}s" fill="freeze" '
                f'calcMode="spline" keySplines="0.2 0 0.2 1"/>'
            )
            parts.append("  </rect>")
        parts.append("</clipPath>")
        parts.append(f'<g clip-path="url(#{clip_id})">')
        parts.append(f'  <text x="0" y="{y:.1f}" class="ascii-row">{text}</text>')
        parts.append("</g>")
        if not STATIC:
            # small block cursor riding the wipe edge
            parts.append(
                f'<rect x="0" y="{y - CHAR_H:.1f}" width="{CHAR_W:.1f}" height="{CHAR_H:.1f}" '
                f'fill="{COLOR}" opacity="0">'
            )
            parts.append(
                f'  <animate attributeName="x" from="0" to="{max(row_w - CHAR_W, 0):.1f}" '
                f'begin="{start:.2f}s" dur="{ROW_DURATION}s" fill="freeze" '
                f'calcMode="spline" keySplines="0.2 0 0.2 1"/>'
            )
            parts.append(
                f'  <animate attributeName="opacity" values="0;0.9;0" '
                f'begin="{start:.2f}s" dur="{ROW_DURATION}s" fill="freeze"/>'
            )
            parts.append("</rect>")

    parts.append("</svg>")
    return "\n".join(parts)


def main():
    lines = image_to_ascii(SRC, COLS, ROWS)
    svg = build_svg(lines, COLS, ROWS)
    with open(OUT, "w") as f:
        f.write(svg)
    print(f"wrote {OUT} ({COLS}x{ROWS} chars, total anim {ROWS*ROW_STAGGER+ROW_DURATION:.1f}s)")


if __name__ == "__main__":
    main()
