"""
prep_photo.py — turn a raw photo into a clean, high-contrast grayscale
image ready for ASCII conversion.

Usage: python scripts/prep_photo.py source-photo.png
Output: source-prepped.png (grayscale, subject on pure white)
"""
import sys
import numpy as np
import cv2
from PIL import Image
from rembg import remove, new_session

ALPHA_THRESHOLD = 60  # kill faint shadow/ghost edges left by the matting model

# Optional (left, top, right, bottom) crop applied BEFORE matting, in case
# the background has a busy element (plants, furniture) that sits right
# next to the subject and gets fused into the cutout. Set to None to skip.
CROP_BOX = None


def main(src_path: str, out_path: str = "source-prepped.png", crop_box=None):
    im = Image.open(src_path).convert("RGB")
    crop_box = crop_box or CROP_BOX
    if crop_box:
        im = im.crop(crop_box)

    # 1) Remove the background so the subject is isolated.
    session = new_session("u2net")
    cut = remove(im, session=session)  # RGBA

    arr = np.array(cut)
    alpha = arr[:, :, 3]

    # Hard-threshold the alpha mask: matting models leave a soft, ghosty
    # halo around busy backgrounds (plants, hair) — a hard cut reads much
    # cleaner once it's reduced to ~13 ASCII density levels.
    mask = (alpha > ALPHA_THRESHOLD).astype(np.uint8) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    mask = cv2.medianBlur(mask, 7)

    # Matting models often fuse small background blobs (leaves, hair
    # strays) onto the subject through a thin bridge. Erode to snap those
    # bridges, keep only the largest component, then dilate back to size.
    eroded = cv2.erode(mask, np.ones((9, 9), np.uint8), iterations=2)
    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(eroded, connectivity=8)
    if n_labels > 1:
        largest = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
        core = np.where(labels == largest, 255, 0).astype(np.uint8)
        # grow the kept core back out, but only within the original mask
        core = cv2.dilate(core, np.ones((9, 9), np.uint8), iterations=3)
        mask = cv2.bitwise_and(mask, core)
    mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)

    rgb = arr[:, :, :3]
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)

    # 2) Boost local contrast — a flatly-lit face converts to a dark,
    # unreadable blob without this.
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    gray = clahe.apply(gray)

    # 3) Composite onto pure white so background -> blank end of the ramp.
    white = np.full_like(gray, 255)
    mask_f = (mask.astype(np.float32) / 255.0)
    composed = (gray.astype(np.float32) * mask_f + white.astype(np.float32) * (1 - mask_f))
    composed = composed.astype(np.uint8)

    Image.fromarray(composed, mode="L").save(out_path)
    print(f"wrote {out_path} ({composed.shape[1]}x{composed.shape[0]})")


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "source-photo.jpg"
    box = tuple(int(v) for v in sys.argv[2].split(",")) if len(sys.argv) > 2 else None
    main(src, crop_box=box)
