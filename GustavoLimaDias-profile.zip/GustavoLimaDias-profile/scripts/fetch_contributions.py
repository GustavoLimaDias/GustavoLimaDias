"""
fetch_contributions.py — scrape the public (no-auth, no-token) HTML
contribution calendar GitHub itself uses on profile pages, and write a
compact JSON with raw days + derived stats.

Usage: python scripts/fetch_contributions.py [username]
Output: data/contributions.json
"""
import json
import sys
from collections import defaultdict
from datetime import datetime, timezone

import requests
from bs4 import BeautifulSoup

USERNAME = "GustavoLimaDias"
URL = "https://github.com/users/{}/contributions"
OUT = "data/contributions.json"


def fetch(username):
    resp = requests.get(
        URL.format(username),
        headers={"User-Agent": "Mozilla/5.0 (profile-readme-bot)"},
        timeout=20,
    )
    resp.raise_for_status()
    return resp.text


def parse(html):
    soup = BeautifulSoup(html, "html.parser")
    cells = soup.select("td.ContributionCalendar-day[data-date]")
    days = []
    for cell in cells:
        date = cell["data-date"]
        level = int(cell.get("data-level", 0))
        count_attr = cell.get("data-count")
        count = int(count_attr) if count_attr is not None else None
        days.append({"date": date, "level": level, "count": count})
    days.sort(key=lambda d: d["date"])

    # total, from the "N contributions in the last year" header
    header = soup.find(id="js-contribution-activity-description")
    total = None
    if header:
        digits = "".join(c for c in header.get_text() if c.isdigit())
        total = int(digits) if digits else None

    return days, total


def derive_stats(days, total):
    # streaks (consecutive days with level > 0, i.e. any contribution)
    longest = current = 0
    trailing = 0  # current streak counted from the most recent day backward
    for d in days:
        active = d["level"] > 0
        current = current + 1 if active else 0
        longest = max(longest, current)

    for d in reversed(days):
        if d["level"] > 0:
            trailing += 1
        else:
            break

    best_day = max(days, key=lambda d: (d["count"] or d["level"])) if days else None

    monthly = defaultdict(int)
    for d in days:
        month = d["date"][:7]  # YYYY-MM
        monthly[month] += d["count"] if d["count"] is not None else d["level"]

    return {
        "total_last_year": total,
        "longest_streak": longest,
        "current_streak": trailing,
        "best_day": best_day,
        "monthly_totals": dict(sorted(monthly.items())),
    }


def main(username=USERNAME):
    html = fetch(username)
    days, total = parse(html)
    stats = derive_stats(days, total)
    payload = {
        "username": username,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "days": days,
        "stats": stats,
    }
    with open(OUT, "w") as f:
        json.dump(payload, f, indent=2)
    print(f"wrote {OUT}: {len(days)} days, {stats['total_last_year']} contributions")


if __name__ == "__main__":
    user = sys.argv[1] if len(sys.argv) > 1 else USERNAME
    main(user)
