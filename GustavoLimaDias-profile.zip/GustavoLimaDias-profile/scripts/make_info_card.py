"""
make_info_card.py — hand-authored neofetch-style SVG panel that fades in
line by line, like it's printing next to the ASCII portrait.

STATIC=1 env var emits a frozen (fully visible) frame for local previews.

Usage: python scripts/make_info_card.py
Output: neofetch-card.svg
"""
import os

STATIC = os.environ.get("STATIC") == "1"
OUT = "neofetch-card.svg"

WIDTH = 490
LINE_H = 24
PAD_TOP = 56
PAD_X = 22
STAGGER = 0.12
FADE_DUR = 0.4

BG = "#0d1117"
BORDER = "#30363d"
TITLE_BAR = "#161b22"
DOT_RED, DOT_YEL, DOT_GRN = "#ff5f56", "#ffbd2e", "#27c93f"
LABEL_COLOR = "#7ee787"
VALUE_COLOR = "#c9d1d9"
PROMPT_COLOR = "#58a6ff"
MUTED = "#8b949e"

# (label, value) rows — the "story numbers can't tell" next to the heatmap
ROWS = [
    ("os", "PUC Minas :: Software Engineering"),
    ("role", "Backend Developer (student)"),
    ("prev", "Intern @ Vallourec — industrial systems"),
    ("stack", "Python · Java · C/C++/C# · JS · FastAPI"),
    ("db", "MySQL · PostgreSQL"),
    ("tools", "Git · GitHub · GitLab · Postman · AWS"),
    ("focus", "APIs, system integration, driver config"),
    ("highlight", "Industrial pipe-marking, intl. integration"),
    ("goal", "Grow as a backend dev on real-world systems"),
]

HEADER_NAME = "gustavo@github"
HEADER_UNDER = "─" * len(HEADER_NAME)


def esc(s):
    return (
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    )


def main():
    n = len(ROWS)
    height = PAD_TOP + n * LINE_H + 26

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {WIDTH} {height}" '
        f'width="{WIDTH}" height="{height}">',
        "<style>",
        ".mono { font-family: 'Courier New', ui-monospace, SFMono-Regular, monospace; }",
        f".label {{ fill: {LABEL_COLOR}; font-weight: bold; }}",
        f".value {{ fill: {VALUE_COLOR}; }}",
        f".muted {{ fill: {MUTED}; }}",
        f".prompt {{ fill: {PROMPT_COLOR}; font-weight: bold; }}",
        "text { font-size: 14px; }",
        "</style>",
        f'<rect x="0.5" y="0.5" width="{WIDTH - 1}" height="{height - 1}" rx="10" '
        f'fill="{BG}" stroke="{BORDER}"/>',
        # title bar
        f'<path d="M1 10 a9 9 0 0 1 9-9 h{WIDTH - 20} a9 9 0 0 1 9 9 v20 h-{WIDTH - 2} z" '
        f'fill="{TITLE_BAR}"/>',
        f'<circle cx="22" cy="20" r="6" fill="{DOT_RED}"/>',
        f'<circle cx="42" cy="20" r="6" fill="{DOT_YEL}"/>',
        f'<circle cx="62" cy="20" r="6" fill="{DOT_GRN}"/>',
        f'<text x="{WIDTH/2}" y="25" text-anchor="middle" class="mono muted">neofetch</text>',
        f'<text x="{PAD_X}" y="48" class="mono prompt">{esc(HEADER_NAME)}</text>',
        f'<text x="{PAD_X}" y="{48+16}" class="mono muted">{HEADER_UNDER}</text>',
    ]

    for i, (label, value) in enumerate(ROWS):
        y = PAD_TOP + 22 + i * LINE_H
        start = 0.3 + i * STAGGER
        label_txt = f"{label}:".ljust(11)
        line = (
            f'<text x="{PAD_X}" y="{y}" class="mono">'
            f'<tspan class="label">{esc(label_txt)}</tspan>'
            f'<tspan class="value">{esc(value)}</tspan>'
            f"</text>"
        )
        if STATIC:
            parts.append(line)
        else:
            parts.append(
                f'<g opacity="0">'
                f'<animate attributeName="opacity" from="0" to="1" '
                f'begin="{start:.2f}s" dur="{FADE_DUR}s" fill="freeze"/>'
                f"{line}</g>"
            )

    parts.append("</svg>")
    with open(OUT, "w") as f:
        f.write("\n".join(parts))
    print(f"wrote {OUT} ({WIDTH}x{height})")


if __name__ == "__main__":
    main()
