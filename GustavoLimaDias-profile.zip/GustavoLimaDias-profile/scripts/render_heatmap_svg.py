"""
render_heatmap_svg.py — draw data/contributions.json as the classic
53-week x 7-day calendar of rounded boxes, revealed with a diagonal
slide-down (plays once on load, then freezes).

STATIC=1 env var emits a frozen (fully visible) frame for local previews.

Usage: python scripts/render_heatmap_svg.py
Output: contrib-heatmap.svg
"""
import json
import os
from collections import defaultdict
from datetime import datetime

STATIC = os.environ.get("STATIC") == "1"
IN_PATH = "data/contributions.json"
OUT = "contrib-heatmap.svg"

CELL = 11
GAP = 3
PAD_LEFT = 28
PAD_TOP = 34
PAD_BOTTOM = 34
DAY_LABELS = ["", "Mon", "", "Wed", "", "Fri", ""]
MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

PALETTE = ["#161b22", "#0e4429", "#006d32", "#26a641", "#39d353", "#69f0a0"]
BG = "#0d1117"
TEXT = "#8b949e"
STRONG_TEXT = "#c9d1d9"

STAGGER = 0.012   # seconds between each cell's start, diagonal by (week+dow)
CELL_DUR = 0.28


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def load():
    with open(IN_PATH) as f:
        return json.load(f)


def to_weeks(days):
    """Bucket days into GitHub-style Sunday-start weeks."""
    by_date = {d["date"]: d for d in days}
    dates = sorted(by_date)
    if not dates:
        return []
    first = datetime.strptime(dates[0], "%Y-%m-%d")
    # back up to the preceding Sunday so week columns align like GitHub's grid
    lead_pad = (first.weekday() + 1) % 7  # Mon=0..Sun=6 -> Sun=0
    weeks = []
    week = [None] * lead_pad
    for date_str in dates:
        d = by_date[date_str]
        week.append(d)
        if len(week) == 7:
            weeks.append(week)
            week = []
    if week:
        week += [None] * (7 - len(week))
        weeks.append(week)
    return weeks


def month_ticks(weeks):
    ticks = []
    last_month = None
    last_wi = -999
    for wi, week in enumerate(weeks):
        for day in week:
            if day is None:
                continue
            m = day["date"][5:7]
            if m != last_month:
                if wi - last_wi >= 3:  # skip labels that would overlap
                    ticks.append((wi, MONTH_LABELS[int(m) - 1]))
                    last_wi = wi
                last_month = m
            break
    return ticks


def main():
    data = load()
    days = data["days"]
    stats = data["stats"]
    username = data["username"]
    weeks = to_weeks(days)
    n_weeks = len(weeks)

    width = PAD_LEFT + n_weeks * (CELL + GAP) + 90  # extra room for legend
    height = PAD_TOP + 7 * (CELL + GAP) + PAD_BOTTOM

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
        f'width="{width}" height="{height}">',
        "<style>",
        ".mono { font-family: 'Courier New', ui-monospace, SFMono-Regular, monospace; }",
        f"text {{ fill: {TEXT}; font-size: 10px; }}",
        "</style>",
        f'<rect width="100%" height="100%" rx="10" fill="{BG}"/>',
        f'<text x="{PAD_LEFT}" y="18" class="mono" fill="{STRONG_TEXT}" '
        f'font-size="13">{esc(username)} :: contributions</text>',
    ]

    # day-of-week labels
    for i, label in enumerate(DAY_LABELS):
        if not label:
            continue
        y = PAD_TOP + i * (CELL + GAP) + CELL - 1
        parts.append(f'<text x="4" y="{y}" class="mono">{label}</text>')

    # month labels
    for wi, label in month_ticks(weeks):
        x = PAD_LEFT + wi * (CELL + GAP)
        parts.append(f'<text x="{x}" y="{PAD_TOP - 8}" class="mono">{label}</text>')

    # cells, diagonal reveal by (week_index + day_index)
    max_delay_units = n_weeks + 6
    for wi, week in enumerate(weeks):
        for di, day in enumerate(week):
            if day is None:
                continue
            level = max(0, min(day["level"], len(PALETTE) - 1))
            color = PALETTE[level]
            x = PAD_LEFT + wi * (CELL + GAP)
            y = PAD_TOP + di * (CELL + GAP)
            delay = (wi + di) * STAGGER
            rect_attrs = (
                f'x="{x}" y="{y}" width="{CELL}" height="{CELL}" rx="2" ry="2" '
                f'fill="{color}"'
            )
            title = f"{day['date']}: level {level}"
            if STATIC:
                parts.append(f'<rect {rect_attrs}><title>{esc(title)}</title></rect>')
            else:
                parts.append(
                    f'<rect {rect_attrs} opacity="0" transform="translate(0,-6)">'
                    f'<title>{esc(title)}</title>'
                    f'<animate attributeName="opacity" from="0" to="1" '
                    f'begin="{delay:.3f}s" dur="{CELL_DUR}s" fill="freeze"/>'
                    f'<animateTransform attributeName="transform" type="translate" '
                    f'from="0,-6" to="0,0" begin="{delay:.3f}s" dur="{CELL_DUR}s" '
                    f'fill="freeze" calcMode="spline" keySplines="0.2 0 0.2 1"/>'
                    f"</rect>"
                )

    # legend: Less -> More
    legend_x = PAD_LEFT + n_weeks * (CELL + GAP) + 14
    legend_y = PAD_TOP
    parts.append(f'<text x="{legend_x}" y="{legend_y - 6}" class="mono">Less</text>')
    for i, color in enumerate(PALETTE):
        parts.append(
            f'<rect x="{legend_x}" y="{legend_y + i * (CELL + GAP)}" '
            f'width="{CELL}" height="{CELL}" rx="2" fill="{color}"/>'
        )
    parts.append(
        f'<text x="{legend_x}" y="{legend_y + len(PALETTE) * (CELL + GAP) + 8}" '
        f'class="mono">More</text>'
    )

    # stats footer
    total = stats.get("total_last_year")
    longest = stats.get("longest_streak")
    footer = f"{total} contributions in the last year  ·  longest streak {longest}d"
    parts.append(
        f'<text x="{PAD_LEFT}" y="{height - 10}" class="mono" fill="{STRONG_TEXT}">'
        f"{esc(footer)}</text>"
    )

    parts.append("</svg>")
    with open(OUT, "w") as f:
        f.write("\n".join(parts))
    print(f"wrote {OUT} ({width:.0f}x{height:.0f}, {n_weeks} weeks)")


if __name__ == "__main__":
    main()
